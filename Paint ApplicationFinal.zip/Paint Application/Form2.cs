﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_Application
{

    public partial class Form2 : Form
    {
        private static float penThickness = 1F;
        public Form2()
        {
            InitializeComponent();
            this.Width = 950;
            this.Height = 700;
            bm = new Bitmap(pic.Width, pic.Height);
            g = Graphics.FromImage(bm);
            g.Clear(Color.White);
            pic.Image = bm;

            trackBar1.Minimum = 1;
            trackBar1.Maximum = 20;
            trackBar1.Value = (int)penThickness;
            trackBar1.Scroll += trackBar1_Scroll;

            newToolStripMenuItem.Click += newToolStripMenuItem_Click;
            openToolStripMenuItem.Click += openToolStripMenuItem_Click;
            cutToolStripMenuItem.Click += cutToolStripMenuItem_Click;
            copyToolStripMenuItem.Click += copyToolStripMenuItem_Click;
            pasteToolStripMenuItem.Click += pasteToolStripMenuItem_Click;
            enableToolStripMenuItem.Click += enableToolStripMenuItem_Click;
            disableToolStripMenuItem.Click += disableToolStripMenuItem_Click;

            btn_txt.Click += btn_txt_Click;
            textBox1.Visible = false;


        }
        private Button selectedButton = null;
        private DrawableObject lastSelectedObject = null;
        private bool isObjectSelected = false;
        Bitmap bm;
        Graphics g;
        bool paint = false;
        Point px, py;
        private int Px, Py;
        Pen p = new Pen(Color.Black, 1);
        Pen eraser = new Pen(Color.White, 10);
        int index;
        int x, y, Sx, Sy, Cx, Cy;

        ColorDialog cd = new ColorDialog();
        Color new_Color;

        private void pic_Click(object sender, EventArgs e)
        {

        }

        private void btn_ellipse_Click(object sender, EventArgs e)
        {
            index = 3;
            selectedButton = btn_ellipse;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;

            }
        }
        private void btn_rect_Click(object sender, EventArgs e)
        {
            index = 4;
            selectedButton = btn_rect;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;

            }
        }

        private void btn_line_Click(object sender, EventArgs e)
        {
            index = 5;
            selectedButton = btn_line;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;

            }
        }

        private void pic_color2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pic_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (paint)
            {

                if (index == 3)
                {
                    g.DrawEllipse(p, Cx, Cy, Sx, Sy);
                }
                if (index == 4)
                {
                    g.DrawRectangle(p, Cx, Cy, Sx, Sy);
                }
                if (index == 5)
                {
                    g.DrawLine(p, Cx, Cy, x, y);
                }
                if (index == 6)
                {
                    Point[] trianglePoints = {
                    new Point(Cx + Sx / 2, Cy),
                    new Point(Cx, Cy + Sy),
                    new Point(Cx + Sx, Cy + Sy)
                                };
                    g.DrawPolygon(p, trianglePoints);

                }
                if (index == 8)
                {
                    Point[] starPoints = GetStarPoints(Cx, Cy, Sx, Sy);
                    g.DrawPolygon(p, starPoints);
                }

            }
        }
        private Point[] GetStarPoints(int centerX, int centerY, int width, int height)
        {
            Point[] points = new Point[10];
            double angle = Math.PI / 5; // 36 degrees in radians
            int outerRadius = width / 2;
            int innerRadius = outerRadius / 2;

            for (int i = 0; i < 10; i++)
            {
                double r = (i % 2 == 0) ? outerRadius : innerRadius;
                double x = centerX + r * Math.Cos(i * angle);
                double y = centerY - r * Math.Sin(i * angle);
                points[i] = new Point((int)x, (int)y);
            }
            return points;
        }
        private void btn_clear_Click(object sender, EventArgs e)
        {
            g.Clear(Color.White);
            pic.Image = bm;
            index = 0;
        }

        private void btn_color_Click(object sender, EventArgs e)
        {
            cd.ShowDialog();
            new_Color = cd.Color;
            pic_color2.BackColor = cd.Color;
            p.Color = cd.Color;
        }

        static Point set_point(PictureBox pb, Point pt)
        {
            float Px = 1f * pb.Image.Width / pb.Width;
            float Py = 1f * pb.Image.Height / pb.Height;
            return new Point((int)(pt.X * Px), (int)(pt.Y * Py));
        }

        private void color_picker_MouseClick(object sender, MouseEventArgs e)
        {
            Point point = set_point(color_picker, e.Location);
            pic_color2.BackColor = ((Bitmap)color_picker.Image).GetPixel(point.X, point.Y);
            new_Color = pic_color2.BackColor;
            p.Color = pic_color2.BackColor;
        }

        private void validate(Bitmap bm, Stack<Point> sp, int x, int y, Color old_color, Color new_color)
        {
            Color cx = bm.GetPixel(x, y);
            if (cx == old_color)
            {
                sp.Push(new Point(x, y));
                bm.SetPixel(x, y, new_color);
            }
        }

        public void Fill(Bitmap bm, int x, int y, Color new_clr)
        {
            Color old_color = bm.GetPixel(x, y);
            Stack<Point> pixel = new Stack<Point>();
            pixel.Push(new Point(x, y));
            bm.SetPixel(x, y, new_clr);
            if (old_color == new_clr)
                return;
            while (pixel.Count > 0)
            {
                Point pt = (Point)pixel.Pop();
                if (pt.X > 0 && pt.Y > 0 && pt.X < bm.Width - 1 && pt.Y < bm.Height - 1)
                {
                    validate(bm, pixel, pt.X - 1, pt.Y, old_color, new_clr);
                    validate(bm, pixel, pt.X, pt.Y - 1, old_color, new_clr);
                    validate(bm, pixel, pt.X + 1, pt.Y, old_color, new_clr);
                    validate(bm, pixel, pt.X, pt.Y + 1, old_color, new_clr);
                }
            }
        }

        private void pic_MouseClick(object sender, MouseEventArgs e)
        {

            if (index == 9)
            {
                string inputText = textBox1.Text;

                if (!string.IsNullOrEmpty(inputText))
                {
                    using (Graphics g = Graphics.FromImage(bm))
                    {
                        g.DrawString(inputText, new Font("Arial", 16), Brushes.Black, e.Location);
                    }

                    pic.Image = bm;
                    pic.Refresh();
                }

                textBox1.Clear();
                textBox1.Visible = false;

            }
            else if (index == 7)
            {


                Point point = set_point(pic, e.Location);
                Fill(bm, point.X, point.Y, new_Color);


            }
        }

        private void btn_fill_Click(object sender, EventArgs e)
        {
            index = 7;
            selectedButton = btn_fill;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;

            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            penThickness = trackBar1.Value;
            p.Width = penThickness;
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            g.Clear(Color.White);
            pic.Image = bm;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {

                    Bitmap image = new Bitmap(openFileDialog.FileName);
                    g.Clear(Color.White);
                    g.DrawImage(image, 0, 0, pic.Width, pic.Height);
                    pic.Image = bm;
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var sfd = new SaveFileDialog();
            sfd.Filter = "Image(*.jpg|*.jpg|(*.*|*.*";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                Bitmap btm = bm.Clone(new Rectangle(0, 0, pic.Width, pic.Height), bm.PixelFormat);
                btm.Save(sfd.FileName, ImageFormat.Jpeg);
                MessageBox.Show("Imgae has succesfully been saved!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            index = 6;
            selectedButton = btn_tri;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            index = 8;
            selectedButton = btn_star;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;

            }
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (isObjectSelected)
            {
                CopyLastSelectedObject();
                ClearLastSelectedObject();
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CopyLastSelectedObject();
        }
        private void CopyLastSelectedObject()
        {

            if (lastSelectedObject != null)
            {
                Clipboard.SetData("DrawableObject", lastSelectedObject);

            }
        }
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsData("DrawableObject"))
            {
                lastSelectedObject = (DrawableObject)Clipboard.GetData("DrawableObject");
                if (lastSelectedObject != null)
                {
               
                    lastSelectedObject.Position = new Point(lastSelectedObject.Position.X + 10, lastSelectedObject.Position.Y + 10);

                    using (Graphics g = Graphics.FromImage(bm))
                    {
                        DrawObject(g, lastSelectedObject);
                    }

                    pic.Image = bm; 
                    pic.Refresh();
                    isObjectSelected = true; // Mark as selected again
                }
                else
                {
                    MessageBox.Show("The pasted object is not valid.");
                }
            }
            else
            {
                MessageBox.Show("No object to paste!");
            }

        }
        private void ClearLastSelectedObject()
        {
            lastSelectedObject = null;  
            isObjectSelected = false;  
        }
        private void DrawObject(Graphics g, DrawableObject obj)
        {
            if (obj != null)  
            {
                if (obj.ShapeIndex == 3)  
                {
                    g.DrawEllipse(p, obj.Position.X, obj.Position.Y, obj.Size.Width, obj.Size.Height);
                }
                else if (obj.ShapeIndex == 4)  
                {
                    g.DrawRectangle(p, obj.Position.X, obj.Position.Y, obj.Size.Width, obj.Size.Height);
                }
                else if (obj.ShapeIndex == 5)  
                {
                    g.DrawLine(p, obj.Position.X, obj.Position.Y, obj.Position.X + obj.Size.Width, obj.Position.Y + obj.Size.Height);
                }
               
            }
        }

        private void enableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (selectedButton != null)
            {
                selectedButton.Enabled = true;
            }
        }

        private void btn_txt_Click(object sender, EventArgs e)
        {
            index = 9;
            selectedButton = btn_txt;
            textBox1.Visible = true;
            textBox1.Focus();
        }
        private void btnConfirmText_Click(object sender, EventArgs e)
        {

        }

        private void disableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (selectedButton != null)
            {
                selectedButton.Enabled = false;
            }
        }

        private void pic_MouseDown(object sender, MouseEventArgs e)
        {
            paint = true;
            py = e.Location;
            Cx = e.X; Cy = e.Y;
        }

        private void pic_MouseMove(object sender, MouseEventArgs e)
        {
            if (paint)
            {
                if (index == 1)
                {
                    px = e.Location;
                    g.DrawLine(p, px, py);
                    py = px;
                }
                if (index == 2)
                {
                    px = e.Location;
                    g.DrawLine(eraser, px, py);
                    py = px;
                }

            }
            pic.Refresh();
            x = e.X; y = e.Y;
            Sx = e.X - Cx; Sy = e.Y - Cy;
        }

        private void pic_MouseUp(object sender, MouseEventArgs e)
        {
            paint = false;
            Sx = x - Cx; Sy = y - Cy;
            lastSelectedObject = new DrawableObject
            {
                Position = new Point(Cx, Cy),
                Size = new Size(Sx, Sy),
                ShapeIndex = index
            };

            if (index == 3)
            {
                g.DrawEllipse(p, Cx, Cy, Sx, Sy);
            }
            if (index == 4)
            {
                g.DrawRectangle(p, Cx, Cy, Sx, Sy);
            }
            if (index == 5)
            {
                g.DrawLine(p, Cx, Cy, x, y);
            }
            if (index == 6)
            {

                Point[] trianglePoints = {
                   new Point(Cx + Sx / 2, Cy),
                   new Point(Cx, Cy + Sy),
                   new Point(Cx + Sx, Cy + Sy)
    };
                g.DrawPolygon(p, trianglePoints);
            }
            if (index == 8)
            {
                Point[] starPoints = GetStarPoints(Cx, Cy, Sx, Sy);
                g.DrawPolygon(p, starPoints);
            }
             
        
            isObjectSelected = true; 
            pic.Image = bm;

        }


    private void btn_pencil_Click(object sender, EventArgs e)
        {
            index = 1;
            selectedButton = btn_pencil;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;
            }

        }

        private void btn_eraser_Click(object sender, EventArgs e)
        {
            index = 2;
            selectedButton = btn_eraser;
            if (!selectedButton.Enabled)
            {
                selectedButton.Enabled = true;
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

    }
    public class DrawableObject
    {
        public int ShapeIndex { get; set; }
        public Point Position { get; set; }
        public Size Size { get; set; }  
    }
}
